export declare class PortfolioClient {
    private baseUrl;
    private headers;
    constructor();
    fetchProfile(): Promise<unknown>;
    fetchProjects(): Promise<unknown>;
    fetchExperience(): Promise<unknown>;
    fetchEducation(): Promise<unknown>;
}
