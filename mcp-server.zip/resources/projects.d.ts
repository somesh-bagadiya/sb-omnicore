import { Server } from '@modelcontextprotocol/sdk/server/index.js';
export declare function registerProjectsResource(server: Server): void;
