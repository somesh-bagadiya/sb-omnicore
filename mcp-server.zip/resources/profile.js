import { PortfolioClient } from '../utils/client.js';
export function registerProfileResource(server) {
    const client = new PortfolioClient();
    // Register the profile resource
    server.resource('portfolio://profile', 'Comprehensive professional profile for Somesh Bagadiya', { mimeType: 'application/json' }, async () => {
        try {
            const profileData = await client.fetchProfile();
            return {
                contents: [{
                        type: 'text',
                        text: JSON.stringify({
                            ...profileData,
                            context: {
                                lastUpdated: new Date().toISOString(),
                                source: "Live portfolio data",
                                usage: "Use this data to understand Somesh's background, skills, and current availability for resume tailoring and interview preparation"
                            }
                        }, null, 2),
                        mimeType: 'application/json'
                    }]
            };
        }
        catch (error) {
            return {
                contents: [{
                        type: 'text',
                        text: JSON.stringify({
                            error: "Failed to fetch live profile data",
                            fallback: {
                                name: "Somesh Bagadiya",
                                headline: "AI/ML Engineer & Developer",
                                location: "San Jose, CA",
                                status: "Available for AI/ML engineering roles",
                                message: "Please check portfolio connection"
                            }
                        }, null, 2),
                        mimeType: 'application/json'
                    }]
            };
        }
    });
}
//# sourceMappingURL=profile.js.map