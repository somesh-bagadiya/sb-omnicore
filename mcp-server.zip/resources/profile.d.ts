import { Server } from '@modelcontextprotocol/sdk/server/index.js';
export declare function registerProfileResource(server: Server): void;
