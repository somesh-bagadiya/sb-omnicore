import { PortfolioClient } from '../utils/client.js';
export function registerProjectsResource(server) {
    const client = new PortfolioClient();
    // Register the projects resource
    server.resource('portfolio://projects', 'Complete project portfolio with resume-optimized descriptions', { mimeType: 'application/json' }, async () => {
        try {
            const projectsData = await client.fetchProjects();
            return {
                contents: [{
                        type: 'text',
                        text: JSON.stringify({
                            ...projectsData,
                            resumeGuidance: {
                                featuredProjects: "Use these featured projects for most resumes - they represent your strongest work",
                                domainSelection: "Filter by domain based on job requirements (GenAI for AI roles, Web & Cloud for full-stack)",
                                descriptionFormats: "Choose technical/business/academic based on role type and company culture",
                                impactMetrics: "Always include quantified results when available"
                            },
                            context: {
                                totalProjects: projectsData.totalCount || 16,
                                lastUpdated: new Date().toISOString(),
                                source: "Live portfolio data",
                                usage: "Use this project portfolio to understand Somesh's technical capabilities and select relevant projects for resume tailoring"
                            }
                        }, null, 2),
                        mimeType: 'application/json'
                    }]
            };
        }
        catch (error) {
            return {
                contents: [{
                        type: 'text',
                        text: JSON.stringify({
                            error: "Failed to fetch live projects data",
                            message: "Portfolio connection unavailable - please try again"
                        }, null, 2),
                        mimeType: 'application/json'
                    }]
            };
        }
    });
}
//# sourceMappingURL=projects.js.map