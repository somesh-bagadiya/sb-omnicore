import { Server } from '@modelcontextprotocol/sdk/server/index.js';
export declare function registerResumePrompt(server: Server): void;
