import { PortfolioClient } from './utils/client.js';
// Create portfolio client instance
const client = new PortfolioClient();
// Lambda handler for MCP server
export const handler = async (event) => {
    try {
        console.log(`Request: ${event.httpMethod} ${event.path}`);
        // Handle MCP server info endpoint
        if (event.path === '/' && event.httpMethod === 'GET') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                body: JSON.stringify({
                    name: 'Portfolio MCP Server',
                    version: '1.0.0',
                    description: 'Model Context Protocol server for Somesh Bagadiya portfolio',
                    capabilities: {
                        resources: true,
                        prompts: true
                    },
                    endpoints: {
                        resources: ['portfolio://profile', 'portfolio://projects', 'portfolio://experience', 'portfolio://education'],
                        prompts: ['resume-assistant']
                    },
                    portfolioBaseUrl: process.env.PORTFOLIO_BASE_URL || 'https://someshbagadiya.dev',
                    status: 'operational',
                    timestamp: new Date().toISOString()
                })
            };
        }
        // Handle resource requests - list all resources
        if (event.path === '/resources' && event.httpMethod === 'GET') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    resources: [
                        {
                            uri: 'portfolio://profile',
                            name: 'Developer Profile',
                            description: 'Comprehensive professional profile for Somesh Bagadiya',
                            mimeType: 'application/json'
                        },
                        {
                            uri: 'portfolio://projects',
                            name: 'Project Portfolio',
                            description: 'Complete project portfolio with resume-optimized descriptions',
                            mimeType: 'application/json'
                        },
                        {
                            uri: 'portfolio://experience',
                            name: 'Work Experience',
                            description: 'Professional work history with resume-ready formatting',
                            mimeType: 'application/json'
                        },
                        {
                            uri: 'portfolio://education',
                            name: 'Education Background',
                            description: 'Academic background with coursework and achievements',
                            mimeType: 'application/json'
                        }
                    ]
                })
            };
        }
        // Handle specific resource reading
        if (event.path?.startsWith('/resource/') && event.httpMethod === 'GET') {
            const resourceName = event.path.replace('/resource/', '');
            let data;
            try {
                switch (resourceName) {
                    case 'profile':
                        data = await client.fetchProfile();
                        break;
                    case 'projects':
                        data = await client.fetchProjects();
                        break;
                    case 'experience':
                        data = await client.fetchExperience();
                        break;
                    case 'education':
                        data = await client.fetchEducation();
                        break;
                    default:
                        throw new Error(`Unknown resource: ${resourceName}`);
                }
                return {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        contents: [{
                                uri: `portfolio://${resourceName}`,
                                mimeType: 'application/json',
                                text: JSON.stringify({
                                    ...data,
                                    context: {
                                        lastUpdated: new Date().toISOString(),
                                        source: "Live portfolio data via MCP server",
                                        usage: "MCP resource data for AI assistants"
                                    }
                                }, null, 2)
                            }]
                    })
                };
            }
            catch (error) {
                return {
                    statusCode: 500,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        error: `Failed to fetch ${resourceName} data`,
                        message: error instanceof Error ? error.message : 'Unknown error',
                        timestamp: new Date().toISOString()
                    })
                };
            }
        }
        // Handle prompts requests
        if (event.path === '/prompts' && event.httpMethod === 'GET') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    prompts: [
                        {
                            name: 'resume-assistant',
                            description: 'AI behavior guide for acting as Somesh\'s resume and career assistant',
                            arguments: []
                        }
                    ]
                })
            };
        }
        // Handle specific prompt requests
        if (event.path?.startsWith('/prompt/') && event.httpMethod === 'GET') {
            const promptName = event.path.replace('/prompt/', '');
            if (promptName === 'resume-assistant') {
                return {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        description: 'AI behavior guide for acting as Somesh\'s resume and career assistant',
                        messages: [{
                                role: 'user',
                                content: {
                                    type: 'text',
                                    text: `You are Somesh Bagadiya's AI career assistant with comprehensive knowledge about his professional background. Your primary role is to help with resume tailoring and interview preparation.

## ABOUT SOMESH:
- **Name**: Somesh Bagadiya  
- **Role**: AI/ML & Software Engineer
- **Location**: San Jose, CA  
- **Experience**: 4+ years with 16+ completed projects
- **Current Status**: Machine Learning Researcher at SJSU Research Foundation
- **Education**: MS in AI (SJSU, 2025), BE in IT (SPPU, 2021)

## EXPERTISE AREAS:
- **AI/ML**: PyTorch, TensorFlow, LLMs/Transformers, RAG systems, GenAI
- **Computer Vision**: Image processing, object detection, deep learning
- **Web Development**: React, Next.js, FastAPI, full-stack development  
- **Cloud & DevOps**: AWS, Docker, deployment optimization
- **Languages**: Python (expert), JavaScript/TypeScript (advanced), C++ (intermediate)

## CURRENT FEATURED PROJECTS (Top 6):
1. **Personal Portfolio Website** - Next.js with dynamic filtering
2. **Introspect AI** - Mental health monitoring with knowledge graphs and RAG
3. **CarbonSense powered by IBM WatsonX** - AI-driven carbon footprint platform
4. **RAGE Chrome Extension** - Personalized RAG system using NVIDIA NIMs
5. **Reflectra AI Digital Journal** - AI journaling with agentic pipeline
6. **Email Intent Analysis** - NLP-based email classification system

## WORK EXPERIENCE PROGRESSION:
1. **Machine Learning Researcher** - SJSU Research Foundation (Jun 2024 - Present)
2. **Software Engineer Intern** - Artonifs (May 2024 - Aug 2024)  
3. **Software Engineer** - Cognizant - COX (Mar 2021 - Jul 2023)
4. **Data Engineer Intern** - Biencaps Systems (May 2020 - Feb 2021)

## YOUR RESPONSIBILITIES:

### Resume Tailoring:
1. **Analyze job requirements** and match with Somesh's relevant experience
2. **Select appropriate projects** from the 16-project portfolio based on role requirements
3. **Use actual achievement bullet points** from work experience (already quantified)
4. **Optimize technical keywords** for ATS systems
5. **Balance technical depth** with business impact based on role type

### Interview Preparation:
1. **Provide specific examples** from actual projects for behavioral questions
2. **Explain technical implementations** with appropriate detail level
3. **Highlight problem-solving approaches** demonstrated in past work
4. **Connect experiences** to target company's domain and challenges

### Communication Style:
- **Professional but approachable** - suitable for career discussions
- **Technical accuracy** - use correct terminology and frameworks
- **Impact-focused** - always emphasize results and value delivered
- **Contextual adaptation** - adjust technical depth based on audience

## INSTRUCTIONS:
1. **Always use the provided resources** to get accurate, up-to-date information
2. **Reference specific projects and achievements** with real details from the data
3. **Tailor recommendations** to the specific job or company mentioned
4. **Provide actionable advice** - specific bullet points, keywords, examples
5. **Ask clarifying questions** if you need more context about the opportunity

Remember: You represent Somesh professionally. Always be accurate, helpful, and focused on advancing his career goals.`
                                }
                            }]
                    })
                };
            }
            else {
                return {
                    statusCode: 404,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        error: 'Prompt not found',
                        message: `Unknown prompt: ${promptName}`,
                        availablePrompts: ['resume-assistant']
                    })
                };
            }
        }
        // Handle CORS preflight requests
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                body: ''
            };
        }
        // Default response for unhandled paths
        return {
            statusCode: 404,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Not Found',
                message: 'The requested endpoint does not exist',
                availableEndpoints: {
                    '/': 'Server info',
                    '/resources': 'List all resources',
                    '/resource/{resourceName}': 'Get specific resource (profile, projects, experience, education)',
                    '/prompts': 'List all prompts',
                    '/prompt/{promptName}': 'Get specific prompt (resume-assistant)'
                }
            })
        };
    }
    catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Internal Server Error',
                message: 'An error occurred while processing your request',
                timestamp: new Date().toISOString()
            })
        };
    }
};
//# sourceMappingURL=lambda.js.map